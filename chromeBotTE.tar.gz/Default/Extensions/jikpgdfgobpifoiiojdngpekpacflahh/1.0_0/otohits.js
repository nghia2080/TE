document.onreadystatechange = function() {
    if (document.readyState == "complete") {
        if (window.location.href.indexOf("otohits.net/account/login") > -1 || window.location.href.indexOf("otohits.net/account/Login") > -1) {
            $.getJSON(chrome.extension.getURL('account.json'), function(json) {
                $('input#Email')[0].value = json.otohits.account;
                $('input#Password')[0].value = json.otohits.password;
                if (!(json.otohits.account=='otoacc'||json.otohits.password=='otopass'))
                	$('input[type=submit]')[0].click()
            });
        }
        if (window.location.href.indexOf("otohits.net/account/wfautosurf") > -1) {
            $('a#Start')[0].click()
        }
    }
}