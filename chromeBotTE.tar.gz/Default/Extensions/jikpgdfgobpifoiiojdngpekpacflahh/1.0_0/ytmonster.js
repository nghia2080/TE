document.onreadystatechange = function() {
    if (document.readyState == "complete") {
        if (window.location.href.indexOf("ytmonster.net/login") > -1) {
            $.getJSON(chrome.extension.getURL('account.json'), function(json) {
                $('input[type=usernames]')[0].value = json.otohits.account;
                $('input[type=password]')[0].value = json.otohits.password;
                if (!(json.otohits.account=='otoacc'||json.otohits.password=='otopass'))
                	$('button[type=submit]')[0].click()
            });
        }
        if (window.location.href.indexOf("otohits.net/account/wfautosurf") > -1) {
            $('a#Start')[0].click()
        }
    }
}